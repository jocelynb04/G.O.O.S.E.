# Concept 2 — Jason edits

This working copy follows the Concept3_Debug_Copy organization. Concept 2's
parallel-hybrid physics, inputs, mission cases and mass accounting are retained.

| Location | Purpose |
|---|---|
| `untitled.m` | Run button entry point, like Concept 3; leaves `analysis` and `hist` in the workspace |
| `matchingdiagram.m` | Runs the study and displays the motor, turbine and combined constraint diagrams |
| `run_concept2_study.m` | Full study with optional mass closure and sensitivity cases |
| `TtpaAero.m`, `TtpaGeom.m`, `TtpaProp.m`, `TtpaWeights.m` | Aircraft-specific discipline models |
| `ttpa_disciplines.m` | Builds the discipline bundle and enables the shared framework |
| `sizing_mainloop.m`, `sizing_pass.m`, `SizingSteps.m` | Mass closure, hybrid source sizing and sizing utilities |
| `hybrid_*.m` | Concept 2 phase schedules, energy and battery SOC calculations |
| Other top-level `.m` files | Concept 2 configuration, propulsion, constraints and reporting |
| `framework/` | Base classes, aircraft state, importers, shared utilities and landing constraint |
| `concept2.json` | Active aircraft requirements, geometry, missions and source configuration |
| `concept2_study_inputs.json` | Operating assumptions, electrical limits and search settings |
| `turbine_engine_catalog.json` | Engine catalog; stays beside `concept2.json` |
| `study_input_register.csv` | Input provenance and validation needs |
| `Results/Current/` | Latest saved reports and constraint diagrams |
| `Before_Structure_*.zip` | Snapshot of the previous code/input layout and baseline numerical result |

Set MATLAB's current folder to this directory and run `untitled`, or:

```matlab
[analysis,hist] = matchingdiagram();
% Optional weight closure:
[result,hist] = run_concept2_study('sizing',true,'plot_visible',true);
```

`source_sizing_mainloop` and `source_constraint_sizing` remain compatibility
entry points for `sizing_mainloop` and `sizing_pass`. The hybrid sizing signatures
and outputs are retained; they differ from Concept 3's conventional power model.
Separate motor and turbine plots remain necessary for the hybrid installation.
Input edits require a new run. Default runs overwrite matching outputs only in
this copy's `Results/Current` folder.

The starting-aircraft study passes mission/constraints at 12,000 lb but estimates
18,856 lb total mass. This is not a mass-closed design; inspect `mass_closed`
before interpreting feasibility. Hardware and certification validation remain open.


## Constraint diagram style

The primary `concept2_matching_diagram.png` follows Concept 3's W/S-W/P
presentation: white chart, colored constraint curves, green conditional static
region, landing/span limits, blue design diamond, and a yellow minimum-motor-power
marker. The ordinate is motor peak power loading; turbines, battery, SOC and
inverter are held fixed. The minimum marker applies only to this static sweep.
Turbine references and combined source margins remain separate companion figures.
Detailed installation assumptions are stored in each MATLAB figure's `UserData`.
The green region does not imply mission feasibility or mass closure.
